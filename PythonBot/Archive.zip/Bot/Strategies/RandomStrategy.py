from random import randint
from AbstractStrategy import AbstractStrategy
import sys
import numpy as np

class RandomStrategy(AbstractStrategy):
    def __init__(self, game):
        AbstractStrategy.__init__(self, game)
        self._actions = ['left', 'right', 'turnleft', 'turnright', 'down', 'drop']

    def choose(self):
    	"""For all possible moves/rotations, make the move with the highest score."""
        moves = [] 
        best_rot = None
        best_position = None

        # Can probably remove this error check. Should not occur.
        if self._game.piece is not None:
        	rotation_count = len(self._game.piece._rotations)
    	else:
    		moves.append("drop")
    		return moves

        # For each rotation and position (ignoring height for now, just dropping piece down.)
        min_score = sys.maxint
        for r in xrange(rotation_count):
        	for positions in xrange(-3, self._game.me.field.width):
        		field = self._game.me.field.projectPieceDown(self._game.piece, [positions, 0])

        		if field is not None:
        			# calculate a score function
        			score = self.get_height(field)
        			if score < min_score:
        				min_score = score
        				best_rot = r
        				best_position = positions

			self._game.piece.turnRight()

		for _ in range(best_rot): moves.append('turnright')

		pos_dif = self._game.piecePosition[0] - best_position
		
		if pos_dif > 0:
			for _ in range(pos_dif): moves.append('left')
		else:
			for _ in range(abs(pos_dif)): moves.append('right')

        moves.append('drop')
        return moves

    def generateMoves(self):
    	"""Given a target rotation & position, generate a list of moves that 
    	get piece to destination."""
    	pass

    def get_height(self, field):
    	"""Returns height score for a field.
    	Currently using average height (minimize)."""
    	# transpose -> list of columns where the first entry of each list is the top of the column.
    	# for each entry in the columns, if there is a block there, score how high the block is
    	field = np.transpose(np.array(field))
    	score = 0
    	for col in field:
    		score += sum([len(col) - i for i in xrange(len(col)) if col[i] > 0])
		return score

	# def choose(self):
	#     moves = [] # moves list to return

	#     field = self._game.me.field
	#     piece = self._game.piece

	#     max_score = -sys.maxint - 1

	#     best_piece_rotation = None
	#     best_piece_position = None

	#     # loop through all the first piece rotations
	#     for piece_rotations in range(len(piece._rotations)):

	#         # and all the first piece positoins (x only cuz projecting down)
	#         for piece_positions in range(-2,field.width):

	#             # project and test if valid field
	#             test_field = field.projectPieceDown(piece, [piece_positions,0])
	#             if test_field:

	#                 score = self.calculate_field_score(test_field)

	#                 if score > max_score:
	#                     max_score = score
	#                     best_piece_rotation = piece_rotations
	#                     best_piece_position = piece_positions

	#         # turn the first piece once
	#         piece.turnRight(times=1)


	#     for _ in range(best_piece_rotation):
	#         moves.append('turnright')

	#     position_diff = self._game.piecePosition[0] - best_piece_position
	#     for _ in range(position_diff):
	#         if position_diff < 0:
	#             moves.append('right')
	#         elif position_diff > 0:
	#             moves.append('left')


	#     moves.append('drop')

	#     return moves

	#     def calculate_field_score(self, possible_field):
	#         score = 0

	#         holes, complete_lines, total_height, bumpiness = self.get_features(possible_field)

	#         score = -0.510066 * total_height + 0.760666 * complete_lines + -0.35663 * holes + -0.184483 * bumpiness
	#         return score

	#     def get_features(self,possible_field):
	#         width = len(possible_field[0])
	#         height = len(possible_field)

	#         reversed_field = possible_field[::-1]

	#         holes = 0.0
	#         complete_lines = 0.0
	#         total_height = 0.0
	#         bumpiness = 0.0

	#         cur_height = [0]*width
	#         for y in range(height):
	#             complete = True
	#             for x in range(width):

	#                 if reversed_field[y][x] in (2,4):
	#                     if y+1 >= (cur_height[x] + 2):
	#                         holes += 1

	#                     cur_height[x] = y+1

	#                 else:
	#                     complete = False

	#             if complete:
	#                 complete_lines += 1

	#         total_height = sum(cur_height)

	#         for x in range(len(cur_height)-1):
	#             bumpiness += abs(cur_height[x]-cur_height[x+1])

	#         return holes, complete_lines, total_height, bumpiness